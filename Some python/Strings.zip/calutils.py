#tests date, month, (leap) year
#Sihle Calana
#8 April 2018

def is_leap_year(year):
    if year%100 == 0:
        if year%400 == 0:
            return True
        else:
            return False
    elif year%4 == 0:
        return True
    else:
        return False

def month_name(month_number):
    if month_number == 1:
        return 'January'
    elif month_number == 2:
        return 'February'
    elif month_number == 3:
        return 'March'
    elif month_number == 4:
        return 'April'
    elif month_number == 5:
        return 'May'
    elif month_number == 6:
        return 'June'
    elif month_number == 7:
        return 'July'
    elif month_number == 8:
        return 'August'
    elif month_number == 9:
        return 'September'
    elif month_number == 10:
        return 'October'
    elif month_number == 11:
        return 'November'
    elif month_number == 12:
        return 'December'

def days_in_month(month_number, year):
    if month_number == 1 or month_number == 3 or month_number == 5 or month_number == 7 or month_number == 8 or month_number == 10 or month_number == 12:
        return '31'
    elif month_number == 4 or month_number == 6 or month_number == 9 or month_number == 11:
        return '30'
    elif month_number == 2:
        if is_leap_year(year):
            return '29'
        else:
            return '28'

def first_day_of_year(year):
    day = (1+5*((year-1)%4)+4*((year-1)%100)+6*((year-1)% 400))%7
    return (day)


