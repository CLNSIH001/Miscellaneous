
#Sihle Calana
#8 April 2018

def to_pig_latin(s):
    sentence = ''
    for word in s.split():
        if word[0] in ['a', 'e', 'i', 'o', 'u']:
            sentence = sentence + word + 'way' + ' '
        else:
            for k in range(len(word)):
                if word[k] not in 'aeiou':
                    k+=1
                else:
                    break
            sentence = sentence + word[k:] + 'a' + word[:k] + 'ay' + ' '     
    return(sentence)

def to_english(s):
    sentence = ''
    for word in s.split():
        k = len(word)
        if word[k-3:] == 'way':
            sentence = sentence + word[0:k-3] + ' '
        else:
            words = word[0:k-2]
            for c in range(len(words)-1, -1, -1):
                if words[c] in 'aeiou':
                    break
                else:
                    c-=1
            sentence = sentence + words[c+1:] + words[:c] + ' '
    return(sentence)