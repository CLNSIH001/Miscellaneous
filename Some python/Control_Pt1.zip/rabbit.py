#Display a bunny
#3 March 2018
#Sihle Calana

print ("(\\\               (\/)") 
print ("( '')    (\_/)   (.. )   //)")
print ("O(\")(\") (\\'.\'/) (\")(\")O (\" )")
print ('        (")_(")        ()()o')