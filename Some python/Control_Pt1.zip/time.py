#Validity check on time entered
#5 March 2018
#Sihle Calana

a = eval("60")
b = eval("0")
hours = eval (input("Enter the hours: "))
minutes = eval(input("Enter the minutes: "))
seconds = eval(input("Enter the seconds: "))

if 0 <= hours <= 23 and 0 <= minutes <= 59 and 0 <= seconds <= 59:
          print("Your time is valid.")

elif not 0 <= hours <= 23 or 0 <= minutes <= 59 or 0 <= seconds <= 59:
          print("Your time is invalid.")