#
#21 March 2018
#Sihle Calana

n = eval(input("Enter the start number: "))
if n in range(-5,2):
    for n in range(n, n+41, 7):
        for n in range(n,n+7):
            if n in range(10):
                print(' ', end='')
            print(n,'',end='')
        print()