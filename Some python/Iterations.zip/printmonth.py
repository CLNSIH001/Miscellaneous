#
#22 March 2018
#Sihle Calana

month = input("Enter the month('January', ...,'December'): ")
day = input("Enter the start day ('Monday', ..., 'Sunday'): ")
print(month)
print("Mo Tu We Th Fr Sa Su")

if month == "January" or "March" or "May" or "July" or "August" or "October" or "December":
    r = 31
elif month == "February":
    r = 28
elif month == "April" or "June" or "September" or "November":
    r = 30

if day == "Monday":
    sv = 1
elif day == "Tuesday":
    sv = 0
elif day == "Wednesday":
    sv = -1
elif day == "Thursday":
    sv = -2
elif day == "Friday":
    sv = -3
elif day == "Saturday":
    sv = -4
elif day == "Sunday":
    sv = -5

for sv in range(sv, r, 7):
    for sv in range(sv,sv+7):
        if sv<1:
            print(' '*3,end='')
        elif sv>r:
            print(' '*3,end='')
        elif sv in range(1,r+1):
            if sv in range(10):
                print(' ', end='')
            print(sv,'',end='')
    print()