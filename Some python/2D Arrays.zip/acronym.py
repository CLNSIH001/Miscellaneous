#creates acronyms
#Sihle Calana
#3 May 2018

ignore = input("Enter words to be ignored separated by commas:\n")
title = input("Enter a title to generate its acronym:\n")
ignore = ignore.lower()
title = title.lower()
ignore = ignore.split(', ')
title = title.split()
acronym = ''
for i in range(len(ignore)):
    if ignore[i] in title:
        k = title.count(ignore[i])
        title.remove(ignore[i])        
        if k>1:
            title.remove(ignore[i])
for words in title:
    acronym += words[0]
acronym = acronym.upper()
print('The acronym is:',acronym)