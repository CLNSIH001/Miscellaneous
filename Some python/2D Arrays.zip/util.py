def create_grid (grid):
    """create a 4x4 array of zeroes within grid"""
    for row in range(4):
        rows = []
        grid.append(rows)
        for column in range(4):
            rows.append(0)
    return grid

def print_grid (grid):
    """print out a 4x4 grid in 5-width columns within a box"""
    print('+', '-'*18, '+')
    for row in range(4):
        print('|', end='')
        for column in range(4):
            if grid[row][column] == 0:
                print('{0:<5}'.format(''), end='')
            else:
                print('{0:<5}'.format(grid[row][column]), end='')
        print('|')       
    print('+', '-'*18, '+')
    return grid

def check_lost (grid):
    """return True if there are no 0 values and there are no adjacent values that are equal; otherwise False"""
    for x in range(len(grid)):
        for y in range(len(grid[x])):
            if grid[x][y] != 0 and grid[x][y] != grid[x][y+1] and grid[x][y] != grid[x+1][y]: return True
            else: return False

def check_won (grid):
    """return True if a value>=32 is found in the grid; otherwise False"""
    for a in range(len(grid)):
        for b in range(len(grid[a])):
            if grid[a][b] >= 32: return True
    return False

def copy_grid (grid):
    """return a copy of the given grid"""
    c_grid = []
    for i in range(len(grid)):
        rows = []
        c_grid.append(rows)
        for j in grid[i]:
            rows.append(j)
    return c_grid

def grid_equal (grid1, grid2):
    """check if 2 grids are equal - return boolean value"""
    if len(grid1) == len(grid2):
        for a in range(len(grid1)):
            for b in range(len(grid1[a])):
                if grid1[a][b] != grid2[a][b]: return False
    return True