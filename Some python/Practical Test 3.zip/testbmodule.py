def getvalues(ws, s):
    result = []
    for word in ws:
        words = word.lower()
        if words.endswith(s) is True:
            result.append(ws.index(word))
    return result