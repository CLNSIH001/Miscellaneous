
#Sihle Calana
#8 April 2018

def decimal_to_bukiyip(num):
    rev = ''
    while num != 0:
        rem = num % 3
        num = num // 3
        rev = str(rem) + rev
    return(rev)

def bukiyip_to_decimal(num):
    str_deci = str(num)
    if len(str_deci) > 2:
        digit_one = int(str_deci[0])*9
        digit_two = int(str_deci[1])*3
        digit_three = int(str_deci[2])*1
        bukiyip = digit_one + digit_two + digit_three
    elif len(str_deci) > 1:
        digit_two = int(str_deci[0])*3
        digit_three = int(str_deci[1])*1        
        bukiyip = digit_two + digit_three
    else:
        digit_three = int(str_deci[0])*1
        bukiyip = digit_three        
    return(bukiyip)

def bukiyip_add(num1, num2):
    decimal_sum = bukiyip_to_decimal(num1) + bukiyip_to_decimal(num2)
    bukiyip_sum = decimal_to_bukiyip(decimal_sum)
    return(bukiyip_sum)

def bukiyip_multiply(num1, num2):
    decimal_sum = bukiyip_to_decimal(num1) * bukiyip_to_decimal(num2)
    bukiyip_sum = decimal_to_bukiyip(decimal_sum)
    return(bukiyip_sum)    
