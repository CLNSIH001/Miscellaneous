#Calculate the area of a circle
#13 March 2018
#Sihle Calana
from math import sqrt

d = sqrt(2)
f = 2 / d
pi = 2*f

while f != 1:
    d = sqrt(2+d)
    f = 2 / d
    pi = pi*f
    
print("Approximation of pi:",round(pi,3))
r = eval(input("Enter the radius:\n"))
A = pi*r**2
print("Area:",round(A,3))