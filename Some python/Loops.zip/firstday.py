#Finds the first day of the year
#12 March 2018
#Sihle Calana

year = 0
a = eval(input("Enter the first year:\n"))
b = eval(input("Enter the second year:\n"))

for year in range (a, b + 1):
    day = (1+5*((year-1)%4)+4*((year-1)%100)+6*((year-1)% 400))%7
    if day == 0:
        day = "Sunday."
    if day == 1:
        day = "Monday."
    if day == 2:
        day = "Tuesday."
    if day == 3:
        day = "Wednesday."
    if day == 4:
        day = "Thursday."
    if day == 5:
        day = "Friday."
    if day == 6:
        day = "Saturday."
        
    print("The 1st of January",year,"falls on a",day)