# plots graphs
# 21 April 2018
# Sihle Calana
def plot():
    import math
    equation = input("Enter a function f(x):\n")
    for y in range(10,-11,-1):
        for x in range(-10,11):
            if y == round(eval(equation)): print('*',sep='',end='')
            elif y == 0 and x != 0: print('-',sep='',end='')
            elif y ==0 and x == 0: print('+',end='')
            elif y != 0 and x == 0: print('|',sep='',end='')
            else: print(' ',sep='',end='')
        print()
plot()