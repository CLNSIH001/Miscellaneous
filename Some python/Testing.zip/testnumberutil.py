"""
>>> import numberutil
>>> numberutil.aswords(0)
'zero'
>>> numberutil.aswords(15)
'fifteen'
>>> numberutil.aswords(25)
'twenty five'
>>> numberutil.aswords(30)
'thirty'
>>> numberutil.aswords(100)
'one hundred'
>>> numberutil.aswords(110)
'one hundred and ten'
>>> numberutil.aswords(130)
'one hundred and thirty'
>>> numberutil.aswords(135)
'one hundred and thirty five'

"""
import doctest
doctest.testmod(verbose=True)