"""
>>> import timeutil
>>> timeutil.validate(':42 a.m.')
False
>>> timeutil.validate('111:01 p.m.')
False
>>> timeutil.validate('01:10 a.m.')
False
>>> timeutil.validate('5:35 f.m.')
False
>>> timeutil.validate('3:1 a.m.')
False
>>> timeutil.validate('4:20 a.m.')
True

"""
import doctest
doctest.testmod(verbose=True)