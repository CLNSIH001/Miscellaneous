import sys
sys.setrecursionlimit (30000)

def primes(m, n):
    f = 2
    def factors_m(f):
        if m == f: return True
        if m % f != 0: return factors_m(f+1)
        else: return
    def palindromeprimes(m):
        if (factors_m(f)):
            str_m = str(m)
            if len(str_m) < 2: return True
            if str_m[0] == str_m[-1]: return palindromeprimes(str_m[1:len(str_m)-1])
            else: return
    if (palindromeprimes(m)):
        print(m)
    if m == n: return
    else: return (primes(m+1, n))
        


m = int(input("Enter the starting point N:\n"))
n = int(input("Enter the ending point M:\n"))
print("The palindromic primes are:")
primes(m, n)