def match(pattern, word):
    if pattern == '' and word == '': return True
    if len(pattern) != len(word): return False
    if pattern[0] == word[0] or pattern[0] == '?': return match(pattern[1:], word[1:])
    else: return False