def palindrome(get):
    if len(get) < 2: return "Palindrome!"
    if get[0] == get[-1]: return palindrome(get[1:len(get)-1])
    else: return "Not a palindrome!"
get = input("Enter a string:\n")
print(palindrome(get))