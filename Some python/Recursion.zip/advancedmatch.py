def match(pattern, word):
    