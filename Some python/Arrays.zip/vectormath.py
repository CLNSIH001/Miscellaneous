#
#Sihle Calana
#27 February 26

import math

vector_a=input('Enter vector A:\n')
vector_b=input('Enter vector B:\n')

def addition(vector_a, vector_b):
    result=[]
    if len(vector_a)==len(vector_b) and type(vector_a)==list and type(vector_b)==list:
        for i in range(len(vector_a)):
            resultant = eval(vector_a[i]) + eval(vector_b[i])
            result.append(resultant)
        return(result)

def dot_product(vector_a, vector_b):
    pre_prod = []
    product_sum = 0
    if len(vector_a)==len(vector_b):
        for i in range(len(vector_a)):
            product = eval(vector_a[i]) * eval(vector_b[i])
            pre_prod.append(product)    
        for i in range(len(pre_prod)):        
            product_sum += pre_prod[i]
        return(product_sum)   

def normalization(vector):
    pre_square = []
    squared_sum = 0
    for i in range(len(vector)):
        sqr = eval(vector[i])**2
        pre_square.append(sqr)
    for i in range(len(pre_square)):
        squared_sum += pre_square[i]
    norm = math.sqrt(squared_sum)
    norm = round(norm, 2)
    return(norm)
    
if __name__=="__main__":
    vector_a=vector_a.split()
    vector_b=vector_b.split()    
    add = addition(vector_a, vector_b)
    dot = dot_product(vector_a, vector_b)
    norm_a = normalization(vector_a)
    norm_b = normalization(vector_b)
    print('A+B =',add)
    print('A.B =',dot)
    print('|A| =', norm_a)
    print('|B| =', norm_b)