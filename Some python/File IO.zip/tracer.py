#Sihle Calana
#19 May 2018

print("***** Program Trace Utility *****")
Filename=input("Enter the name of the program file: ")
f=open(Filename,'r')
prog=f.readlines()
f.close()

n_prgrm=['"""DEBUG"""\n']
for i in range(len(prog)):
    X=[]
    insert=''
    if 'def' in prog[i]: 
        n_prgrm.append(prog[i])
        if '"""DEBUG"""' not in prog[i+1]: 
            X=prog[i].replace('(',' ').split()
            insert='    """DEBUG""";' + "print('"+ X[1] + "')\n"
            n_prgrm.append(insert)
    if '"""DEBUG"""' in prog[i]:
        pass 
    if '"""DEBUG"""' not in prog[i] and 'def' not in prog[i]:
        n_prgrm.append(prog[i])

if len(n_prgrm)<len(prog):
    n_prgrm=n_prgrm[1:]
fc=open(Filename,'w')
for line in n_prgrm:
    print(line, end='', file=fc)
fc.close()