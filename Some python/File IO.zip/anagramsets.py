#Sihle Calana
#19 May 2018

print("***** Anagram Set Search *****")
word_len=int(input("Enter word len:\n"))
f=open("EnglishWords.txt","r")
words=f.readlines()
f.close()
words=words[60:]

len_words=[]
for word in words:
    if len(word.strip('\n'))==word_len:
        len_words.append(word.strip('\n'))
words=[]

lst_anagrams_lst=[]
Anagram_set=[]

for n_word in len_words:
    n_sorted = ''.join(sorted(n_word))
    for index in range(len(len_words)):
        if n_sorted==''.join(sorted(len_words[index])):
            Anagram_set.append(len_words[index])
    if len(Anagram_set) > 1 and sorted(Anagram_set) not in lst_anagrams_lst: lst_anagrams_lst.append(sorted(Anagram_set))
    Anagram_set=[]    


print("Searching...")
filename=input("Enter file name:\n")
print("Writing results...")
fn=open(filename,'w')
for item in sorted(lst_anagrams_lst):
    print(item, file=fn)
fn.close()