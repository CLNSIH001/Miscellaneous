#Sihle Calana
#19 May 2018

print("***** Anagram Finder *****")

try:
    f=open("EnglishWords.txt","r")
    Word=input("Enter a word:\n")
    Word_sorted = ''.join(sorted([char for char in Word]))
    words=f.readlines()
    f.close()
    words=words[60:]
    Anagrams=[]
    
    for line in words:
        Search_sorted = ''.join(sorted(line.strip("\n")))
        if Word_sorted == Search_sorted:
            Anagrams.append(line.strip("\n"))
        Search_sorted = ''
    New_Anagrams=[]
    for item in Anagrams:
        if item!=Word:
            New_Anagrams.append(item)
    if len(New_Anagrams)!=0: print(sorted(New_Anagrams))
    else: print("Sorry, anagrams of '",Word,"' could not be found.",sep='')

except:
    print("Sorry, could not find file 'EnglishWords.txt'.")