# Finds palindromic primes numbers
# Sihle Calana
# 24 March 2018

n = eval(input("Enter the start point N:\n"))
m = eval(input("Enter the end point M:\n"))

print("The palindromic primes are:") 
for y in range(n+1,m):
    num = str(y)

    new_num = ""
    
    for i in range(len(num)-1,-1,-1):
        new_num += num[i]
        x=int(new_num)
    if x == y:
        if x > 1:
            for p in range(2,x):
                if (x % p) == 0:
                    break
            else:
                print(x)