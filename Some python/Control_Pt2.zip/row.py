#
#21 March 2018
#Sihle Calana

n = eval(input("Enter the start number: "))
if n in range(-5,93):
        for n in range(n,n+7):
                if n in range(10):
                        print(' ',end='')
                print(n,'',end='')